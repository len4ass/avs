#!/bin/bash
as -msyntax=intel -mnaked-reg integrate.asm -o integrate.o