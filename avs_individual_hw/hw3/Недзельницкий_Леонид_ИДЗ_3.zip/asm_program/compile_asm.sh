#!/bin/bash
as main.asm -o asm_program.o
gcc asm_program.o -o asm_program