#!/bin/bash
as -msyntax=intel -mnaked-reg transform_array.asm -o array_func_asm.o